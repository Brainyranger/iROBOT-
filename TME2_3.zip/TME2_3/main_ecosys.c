#include <assert.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <strings.h>
#include "ecosys.h"



#define NB_PROIES 20
#define NB_PREDATEURS 20
#define T_WAIT 40000
#define ITERATION_MAX 200

/* Parametres globaux de l'ecosysteme (externes dans le ecosys.h)*/
float p_ch_dir=0.01;
float p_reproduce_proie=0.4;
float p_reproduce_predateur=0.5;
int temps_repousse_herbe=-15;


int main(void) {
   srand(time(NULL));
   Animal* liste=NULL;
  /* A completer. Part 2:
   * exercice 4: question 1
   */  
   Animal *ani=creer_animal(10,15,10);
   liste=ajouter_en_tete_animal(liste,ani);
   /*on choisit notre direction*/
   ani->dir[0]=1;
   ani->dir[1]=-1;
   /*on bouge*/
   bouger_animaux(ani);
   printf(" abscisse = %d ordonnée = %d \n",ani->x,ani->y);
   afficher_ecosys(liste, NULL);
   /* exercie 4: question 2 */
   printf("\navant reproduction \n");
   printf(" X animal =  %d \n",compte_animal_rec(liste));
   reproduce(&liste,1.0);
   printf("\naprès reproduction \n");
   printf(" X animal =  %d \n",compte_animal_rec(liste));
   liberer_liste_animaux(liste);
   
   /* exercice 5: question 2*/
   Animal *liste_proie=NULL;
   int p;
  for(p=0;p<20;p++){
    ajouter_animal((int)rand()%SIZE_X,(int)rand()%SIZE_Y,10,&liste_proie);
  }
 
   /*exercice 6:question 2*/
   
   /*création de mes prédateurs */
  Animal *liste_predateur=creer_animal(5,5,10);
  for (int p=1;p<20;p++){
    ajouter_animal(rand()%SIZE_X, rand()%SIZE_Y, 10,&liste_predateur);
  }
  /*état initial de notre écosystème avec nos prédateurs et nos proies */
  printf("\n\n");
  printf("     état initial de notre écosystème\n\n");
  afficher_ecosys(liste_proie,liste_predateur);
  /*évolution de l'écosystème */
   
   // Initialisation du monde
  int monde[SIZE_X][SIZE_Y];
  for (int i = 0; i < SIZE_X; i++) {
    for (int j = 0; j < SIZE_Y; j++) {
      monde[i][j] = 0;
    }
  }
  int k = ITERATION_MAX;
  while(liste_proie && liste_predateur && k != 0){
  	rafraichir_proies(&liste_proie,monde);
    	rafraichir_predateurs(&liste_predateur, &liste_proie);
    	rafraichir_monde(monde);
    	afficher_ecosys(liste_proie,liste_predateur);
    	usleep(T_WAIT);
    	k--;
  }
  
  

  
  liberer_liste_animaux(liste_proie);
  liberer_liste_animaux(liste_predateur);
  
   /* exercice 8, question 1*/
 

  return 0;
}

