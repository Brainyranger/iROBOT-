#include <assert.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#include "ecosys.h"


int main(){
	int i,x1=0,y1=0,x2=0,y2=0;
	Animal* liste_proies=NULL;
	Animal* liste_predateurs=NULL;
	
	for(i=0;i<20;i++){
	ajouter_animal((int)rand()%SIZE_X,(int)rand()%SIZE_Y,10,&liste_proies);
	ajouter_animal((int)rand()%SIZE_X,(int)rand()%SIZE_Y,10,&liste_predateurs);
	}
	/*On crée quelques animaux pour nos tests.*/
	
	Animal* beats1=creer_animal(13,17,10);
	Animal* beats2=creer_animal(19,1,10);
	ajouter_animal(13,17,10,&liste_proies);
	liste_proies=ajouter_en_tete_animal(liste_proies,beats1);
	liste_predateurs=ajouter_en_tete_animal(liste_predateurs,beats2);
	ajouter_animal(3,9,10,&liste_predateurs);
	
	
	int nbproie=compte_animal_it(liste_proies);
  	int nbpred=compte_animal_it(liste_predateurs);
  	
  	printf("Voici le nombre de proies et de prédateurs\n");
 	printf("Nb proies : %5d\tNb predateurs : %5d\n", nbproie, nbpred);
 	
 	/* on enlève quelques animaux*/
 	enlever_animal(&liste_proies,beats1);
 	enlever_animal(&liste_predateurs,beats2);
 	/*on recompte*/
 	nbproie=compte_animal_it(liste_proies);
  	nbpred=compte_animal_it(liste_predateurs);
  	/*on affiche le résultat*/
  	printf("On enlève 1 prédateur et 1 proie\n");
 	printf("Nb proies : %5d\tNb predateurs : %5d\n", nbproie, nbpred);
 	ecrire_ecosys("file", &liste_predateurs, &liste_proies);
 	liberer_liste_animaux(liste_proies);
 	liberer_liste_animaux(liste_predateurs);
 	
 	/*lecture et sortie du fichier*/
 	Animal *liste_predateur = NULL;
  	Animal *liste_proie = NULL;

  	lire_ecosys("file", &liste_predateurs, &liste_proies);
  	afficher_ecosys(liste_proies, liste_predateurs);

  	liberer_liste_animaux(liste_predateurs);
  	liberer_liste_animaux(liste_proies);
 	
 	
 	 
 	return 0;
 }
			
