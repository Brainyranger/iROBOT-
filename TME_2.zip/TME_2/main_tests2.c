#include <assert.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#include "ecosys.h"


int main(){
	int i,x1=0,y1=0,x2=0,y2=0;
	Animal* liste_proies=NULL;
	Animal* liste_predateurs=NULL;
	
	for(i=0;i<20;i++){
		x1=(int)rand()%SIZE_X;
		y1=(int)rand()%SIZE_Y;
		x2=(int)rand()%SIZE_X;
		y2=(int)rand()%SIZE_Y;
		liste_proies=ajouter_en_tete_animal(liste_proies,creer_animal(x1,y1,10));
		liste_predateurs=ajouter_en_tete_animal(liste_predateurs,creer_animal(x2,y2,10));
	}
	
	Animal* beast_supp1=creer_animal(10,10,10);
	Animal* beast_supp2=creer_animal(15,15,10);
	liste_proies=ajouter_en_tete_animal(liste_proies,creer_animal(10,10,10));
	liste_predateurs=ajouter_en_tete_animal(liste_predateurs,creer_animal(15,15,10));
	enlever_animal(&liste_proies,liste_proies);
	
	
	int nbproie=compte_animal_it(liste_proies);
  	int nbpred=compte_animal_it(liste_predateurs);
  	
  
 	printf("Nb proies : %5d\tNb predateurs : %5d\n", nbproie, nbpred);
 	
 	
 	liberer_liste_animaux(liste_proies);
 	liberer_liste_animaux(liste_predateurs);
 	
 	 
 	return 0;
 }
			
