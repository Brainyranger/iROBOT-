from pulp import *
import matplotlib.pyplot as plt 
import math
import csv
file = open("confiserie.csv")
data = csv.reader(file)
Lx:list[float]=[]
Ly:list[float]=[]
for row in data:
    print(row)
    _,y,z=row
    Lx.append(float(y))
    Ly.append(float(z))

Lx[-1]=5.27

# Création du modèle
model = LpProblem(name="Ex01", sense=LpMinimize) 

#nombre de variables
n=17

#n variables x
z = LpVariable.matrix("z", list(range(1,n+1)),lowBound=0) #n variables 
#Variable x1
a = LpVariable("a",  lowBound=0)  
b = LpVariable("b",  lowBound=0)


#Fonction objectif
model += lpSum(z) #on cherche à minimiser la somme des z

i:int
for i in range(0,len(Ly)):
    model += z[i]>=Ly[i]-a-b*Lx[i]
    model += z[i]>=a+b*Lx[i]-Ly[i]

#Résolution du problème
status = model.solve(solver=GLPK(msg=True,keepFiles=True))

# Affiche le statut de la solution (optimale, non borné, etc.)
print("Status:", LpStatus[model.status])

# Affiche la valeur de la fonction objectif
print("objective=", value(model.objective))

#Affiche les valeurs optimales des variables de décision : 
Lz=[]

for i in range(0,n):
    Lz.append(value(a)+value(b)*value(z[i]))# résidus
    print("x[",i,"]=",value(z[i]))


Lzz=[]
for i in range(0,len(Lx)):
        Lzz.append(value(a)+(value(b)*Lx[i]))


plt.scatter(Lx,Ly)
plt.plot(Lx,Lzz)
plt.show()

print("a =",value(a)," b = ",value(b))



