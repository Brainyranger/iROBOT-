from pulp import *
import matplotlib.pyplot as plt 
import math
import csv
file = open("ozoneApprentissage.csv")
data = csv.reader(file)
Ly:list[float]=[]
Lx1:list[float]=[]
Lx2=[]
Lx3=[]
Lx4=[]
for row in data:
    x1,x2,x3,x4,x5=row
    Ly.append(float(x5))
    Lx1.append(float(x1))
    Lx2.append(float(x2))
    Lx3.append(float(x3))
    Lx4.append(float(x4))





# Création du modèle
model = LpProblem(name="Exemple2", sense=LpMinimize) 

#nombre de variables
n=18

#n variables x
z = LpVariable.matrix("z", list(range(1,n+1)),lowBound=0) #n variables 
b0 = LpVariable("b0",  lowBound=0)  
b1 = LpVariable("b1",  lowBound=0)
b2 = LpVariable("b2",  lowBound=0)
b3 = LpVariable("b3",  lowBound=0)
b4 = LpVariable("b4",  lowBound=0)

#Fonction objectif
model += lpSum(x) #on cherche à minimiser la somme des x

i:int
for i in range(0,n):
    z[i]>=Ly[i]-b0-b1*Lx1[i]-b2*Lx2[i]-b3*Lx3[i]-b4*Lx4[i]
    z[i]>=-Ly[i]+b0+b1*Lx1[i]+b2*Lx2[i]+b3*Lx3[i]+b4*Lx4[i]



#Résolution du problème
status = model.solve(solver=GLPK(msg=True,keepFiles=True))

# Affiche le statut de la solution (optimale, non borné, etc.)
print("Status:", LpStatus[model.status])

# Affiche la valeur de la fonction objectif
print("objective=", value(model.objective))

